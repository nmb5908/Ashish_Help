import { Component } from '@angular/core';

@Component({
  selector: 'app-foundation',
  imports: [],
  templateUrl: './foundation.component.html',
  styleUrl: './foundation.component.css'
})
export class FoundationComponent {

}
