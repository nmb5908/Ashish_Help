import { Component } from '@angular/core';

@Component({
  selector: 'app-waste',
  imports: [],
  templateUrl: './waste.component.html',
  styleUrl: './waste.component.css'
})
export class WasteComponent {

}
