export interface Card {
    suit: string; // 'hearts', 'diamonds', 'clubs', 'spades'
    rank: number; // 1-13 (1=Ace, 11=Jack, 12=Queen, 13=King)
    faceUp: boolean;
  }