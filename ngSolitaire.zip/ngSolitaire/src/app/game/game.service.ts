import { Injectable } from '@angular/core';
import { Card } from './models/card';

@Injectable({
  providedIn: 'root'
})
export class GameService {
  columns: Card[][] = Array(7).fill(null).map(() => []);
  stock: Card[] = [];
  waste: Card[] = [];
  foundations: Card[][] = Array(4).fill(null).map(() => []);
  foundationSuits: string[] = ['hearts', 'diamonds', 'clubs', 'spades'];

  constructor() {
    this.initializeGame();
  }

  initializeGame() {
    const deck = this.createDeck();
    this.shuffle(deck);
    for (let i = 0; i < 7; i++) {
      for (let j = 0; j <= i; j++) {
        const card = deck.pop()!;
        card.faceUp = (j === i);
        this.columns[i].push(card);
      }
    }
    this.stock = deck;
    this.waste = [];
    this.foundations.forEach(f => f.length = 0);
  }

  private createDeck(): Card[] {
    const suits = ['hearts', 'diamonds', 'clubs', 'spades'];
    const deck: Card[] = [];
    for (const suit of suits) {
      for (let rank = 1; rank <= 13; rank++) {
        deck.push({ suit, rank, faceUp: false });
      }
    }
    return deck;
  }

  private shuffle(array: Card[]) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [array[i], array[j]] = [array[j], array[i]];
    }
  }

  drawCard() {
    if (this.stock.length > 0) {
      const card = this.stock.pop()!;
      card.faceUp = true;
      this.waste.push(card);
    } else if (this.waste.length > 0) {
      this.stock = this.waste.reverse().map(card => ({ ...card, faceUp: false }));
      this.waste = [];
    }
  }

  moveToFoundation(card: Card, source: Card[]) {
    const foundationIndex = this.foundationSuits.indexOf(card.suit);
    const foundation = this.foundations[foundationIndex];
    if (this.canDropOnFoundation(card, foundation)) {
      source.pop();
      this.foundations[foundationIndex].push(card);
      this.flipTopCard(source);
      this.checkWin();
    }
  }

  canDropOnColumn(cards: Card[], target: Card[]): boolean {
    if (!this.isValidSequence(cards)) return false;
    const bottomCard = cards[0];
    if (target.length === 0) return bottomCard.rank === 13; // King
    const topCard = target[target.length - 1];
    return (bottomCard.rank === topCard.rank - 1) && 
           (this.getColor(bottomCard.suit) !== this.getColor(topCard.suit));
  }

  canDropOnFoundation(card: Card, foundation: Card[]): boolean {
    if (foundation.length === 0) return card.rank === 1; // Ace
    const topCard = foundation[foundation.length - 1];
    return card.suit === topCard.suit && card.rank === topCard.rank + 1;
  }

  isValidSequence(cards: Card[]): boolean {
    for (let i = 1; i < cards.length; i++) {
      if (cards[i].rank !== cards[i - 1].rank - 1 || 
          this.getColor(cards[i].suit) === this.getColor(cards[i - 1].suit)) {
        return false;
      }
    }
    return true;
  }

  getColor(suit: string): string {
    return (suit === 'hearts' || suit === 'diamonds') ? 'red' : 'black';
  }

  flipTopCard(column: Card[]) {
    if (column.length > 0 && !column[column.length - 1].faceUp) {
      column[column.length - 1].faceUp = true;
    }
  }

  checkWin() {
    if (this.foundations.every(f => f.length === 13)) {
      alert('Congratulations! You won!');
    }
  }
}