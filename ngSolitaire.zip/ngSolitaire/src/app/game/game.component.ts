import { Component } from '@angular/core';
import { GameService } from './game.service';
import { WasteComponent } from "../waste/waste.component";
import { StockComponent } from "../stock/stock.component";
import { FoundationComponent } from "../foundation/foundation.component";

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css'],
  imports: [WasteComponent, StockComponent, FoundationComponent]
})
export class GameComponent {
  columns: any;
  stock: any;
  waste: any;
  foundations: any;
  foundationSuits: any;

  ngOnInit() {
    this.columns = this.gameService.columns;
    this.stock = this.gameService.stock;
    this.waste = this.gameService.waste;
    this.foundations = this.gameService.foundations;
    this.foundationSuits = this.gameService.foundationSuits;
  }

  constructor(private gameService: GameService) {}
}