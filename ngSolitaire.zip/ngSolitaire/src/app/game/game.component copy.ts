import { Component } from '@angular/core';
import { GameService } from './g';

@Component({
  selector: 'app-game',
  templateUrl: './game.component.html',
  styleUrls: ['./game.component.css']
})
export class GameComponent {
  columns = this.gameService.columns;
  stock = this.gameService.stock;
  waste = this.gameService.waste;
  foundations = this.gameService.foundations;
  foundationSuits = this.gameService.foundationSuits;

  constructor(private gameService: GameService) {}
}